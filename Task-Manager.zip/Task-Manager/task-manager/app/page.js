"use client";

import { useState, useEffect } from "react";


const fetchInitialTasks = async () => [
  { id: 1, title: "Sample Task", description: "This is a sample task", priority: "High", completed: false },
];

export default function Home() {
  const [tasks, setTasks] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [editingTask, setEditingTask] = useState(null);
  const [isSorted, setIsSorted] = useState(false); 

  // Load tasks from localStorage or fallback 
  useEffect(() => {
    const loadTasks = async () => {
      try {
        const savedTasks = JSON.parse(localStorage.getItem("tasks"));
        if (savedTasks && Array.isArray(savedTasks)) {
          setTasks(savedTasks);
        } else {
          const initialTasks = await fetchInitialTasks();
          setTasks(initialTasks);
        }
      } catch (error) {
        console.error("Error loading tasks:", error);
        const initialTasks = await fetchInitialTasks();
        setTasks(initialTasks);
      }
    };
    loadTasks();
  }, []);

  // Save tasks to localStorage when tasks change
  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  const addOrUpdateTask = () => {
    if (!title || !description) return alert("Please fill all fields.");

    if (editingTask) {
      const updatedTasks = tasks.map((task) =>
        task.id === editingTask.id ? { ...task, title, description, priority } : task
      );
      setTasks(updatedTasks);
      setEditingTask(null);
    } else {
      const newTask = { id: Date.now(), title, description, priority, completed: false };
      setTasks([...tasks, newTask]);
    }

    setTitle("");
    setDescription("");
    setPriority("Medium");
  };

  const startEditing = (task) => {
    setEditingTask(task);
    setTitle(task.title);
    setDescription(task.description);
    setPriority(task.priority);
  };

  const toggleCompletion = (id) => {
    const updatedTasks = tasks.map((task) =>
      task.id === id ? { ...task, completed: !task.completed } : task
    );
    setTasks(updatedTasks);
  };

  const deleteTask = (id) => setTasks(tasks.filter((task) => task.id !== id));


  const toggleSort = () => setIsSorted(!isSorted);

  // Filtering tasks based on search input here
  const filteredTasks = tasks.filter((task) =>
    task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    task.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Sorting tasks if the sort button is pressed
  const sortedTasks = [...filteredTasks].sort((a, b) => {
    const priorityOrder = { High: 1, Medium: 2, Low: 3 };
    if (isSorted) {
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    }
    return 0; 
  });


const getPriorityColor = (priority) => {
  switch (priority) {
    case "High":
      return "#f8b3ad"; // Light Red
    case "Medium":
      return "#fff59d"; // Light Yellow
    case "Low":
      return "#d4eec7"; // Light Green
    default:
      return "#f0f0f0"; // Light Gray
  }
};

   return (
    <div style={styles.container}>
      <h1 style={styles.header}>TASKR (Task Manager App)</h1>

      <div style={styles.searchSortContainer}>
        <input
          type="text"
          placeholder="Search tasks by title or description"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          style={styles.searchInput}
        />
        <button onClick={toggleSort} style={styles.sortButton}>
          {isSorted ? "Unsort Tasks" : "Sort Tasks"}
        </button>
      </div>

      <div style={styles.formContainer}>
        <div style={styles.form}>
          <input
            type="text"
            placeholder="Task Title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            style={styles.input}
          />
          <textarea
            placeholder="Task Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            style={styles.textarea}
          />
          <select
            value={priority}
            onChange={(e) => setPriority(e.target.value)}
            style={styles.select}
          >
            <option value="High">High</option>
            <option value="Medium">Medium</option>
            <option value="Low">Low</option>
          </select>
          <button onClick={addOrUpdateTask} style={styles.button}>
            {editingTask ? "Update Task" : "Add Task"}
          </button>
          {editingTask && (
            <button
              onClick={() => setEditingTask(null)}
              style={styles.cancelButton}
            >
              Cancel Edit
            </button>
          )}
        </div>
      </div>

      <h2 style={styles.subHeader}>Tasks</h2>
      <div style={styles.taskListContainer}>
        {sortedTasks.length === 0 ? (
          <p style={{ color: "red" }}>No tasks available.</p>
        ) : (
          <ul style={styles.taskList}>
            {sortedTasks.map((task) => (
              <li
                key={task.id}
                style={{
                  ...styles.taskItem,
                  backgroundColor: getPriorityColor(task.priority),
                }}
              >
                <h3 style={styles.taskText}>{task.title}</h3>
                <p style={styles.taskText}>{task.description}</p>
                <p style={styles.taskText}>
                  <strong>Priority: </strong> {task.priority}
                </p>
                <button
                  onClick={() => toggleCompletion(task.id)}
                  style={styles.taskButton}
                >
                  {task.completed ? "Mark as Pending" : "Mark as Completed"}
                </button>
                <button
                  onClick={() => startEditing(task)}
                  style={styles.taskButton}
                >
                  Edit
                </button>
                <button
                  onClick={() => deleteTask(task.id)}
                  style={styles.deleteButton}
                >
                  Delete
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );

}


const styles = {
   container: {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center", 
    alignItems: "center", 
    padding: "20px",
    maxWidth: "600px",
    margin: "auto",
    height: "100vh", 
    
    backgroundColor: "#fff",
    borderRadius: "10px",
    boxShadow: "0 0 10px rgba(0, 0, 0, 0.1)",
  },
    formContainer: {
    marginBottom: "20px",
    width: "100%",
  },
  taskListContainer: {
    flexGrow: 1,
    overflowY: "auto", 
    width: "100%",
    maxHeight: "400px", 
    marginTop: "20px", 
  },
  header: {
    textAlign: "center",
    color: "green",
    fontSize: "2rem",
    fontWeight: "bold",
    padding: "20px"

  },
  formContainer: {
    marginBottom: "20px",
    width: "100%", 
  },
  form: {
    display: "flex",
    flexDirection: "column",
    alignItems: "stretch", 
  },
  input: {
    width: "100%",
    marginBottom: "10px",
    padding: "8px",
    borderRadius: "15px",
    border: "3px solid #ddd",
    color: "black",
  },
  textarea: {
    width: "100%",
    marginBottom: "10px",
    padding: "8px",
    borderRadius: "15px",
    border: "3px solid #ddd",
    color: "black",
  },
  select: {
    width: "100%",
    marginBottom: "10px",
    padding: "8px",
    borderRadius: "15px",
    border: "3px solid #ddd",
    color: "black",
  },
  button: {
    width: "100%",
    padding: "10px",
    backgroundColor: "#4caf50",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
  cancelButton: {
    marginTop: "10px",
    width: "100%",
    padding: "10px",
    backgroundColor: "#f44336",
    color: "#fff",
    border: "none",
    borderRadius: "5px",
    cursor: "pointer",
  },
  subHeader: {
    marginTop: "20px",
    color: "black",
  },
  taskList: {
    listStyle: "none",
    padding: 0,
    width: "100%", 
  },
  taskItem: {
    marginBottom: "10px",
    padding: "10px",
    border: "1px solid #ddd",
    borderRadius: "5px",
  },
  taskText: {
    color: "black", 
  },
  taskButton: {
    marginRight: "10px",
    padding: "5px 10px",
    borderRadius: "5px",
    border: "none",
    cursor: "pointer",
    color: "black",
  },
  deleteButton: {
    color: "#f44336",
  },

    searchSortContainer: {
    display: "flex",
    width: "100%",
    marginBottom: "20px",
    gap: "10px", 
  },
  searchInput: {
    flex: 1, 
    padding: "12px 16px",
    borderRadius: "20px",
    border: "2px solid #ccc",
    backgroundColor: "#f0f0f0",
    fontSize: "16px",
    color: "black",
    outline: "none",
    boxShadow: "inset 0 1px 3px rgba(0, 0, 0, 0.1)",
    transition: "all 0.3s ease",
  },
  sortButton: {
    padding: "12px 16px",
    backgroundColor: "#4caf50",
    color: "#fff",
    border: "none",
    borderRadius: "20px",
    cursor: "pointer",
    whiteSpace: "nowrap", 
  },
  searchInputFocus: {
    borderColor: "#4caf50",  
  },
};
